Please run this project using the following command 
with all the input files in the same directory:

python3 main.py train.txt test.txt

0th argument : main.py
1st argument : the training corpus in txt format.
2nd argument : the testing corpus in txt format.

Total 257 lines in main.py

The result should be printed in the terminal in 3 Seconds, tested on Mac.

You don't need anything other than the original train.txt and test.txt and main.py. 

The program will generate the preprocessed data for you.